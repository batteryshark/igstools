/* $Id: virtex.h,v 1.1 2002/06/25 09:58:58 stefanl Exp $ */

int virtex_writereg(unsigned short theReg, unsigned short theValue);
unsigned short virtex_readreg(unsigned short theReg);



