#define MACHVEC_PLATFORM_NAME	hpzx1
#include <asm/machvec_init.h>
